import {Table, Button} from "react-bootstrap"

const ProductStockList = ({products}) => {
    return (
       <Table striped bordered hover>
  <thead>
    <tr>
      <th>Sr.</th>
      <th>Product ID</th>
      <th>Product Name</th>
      <th>Quantity</th>
    </tr>
  </thead>
  <tbody>
    
  </tbody>
</Table>
    )
}

export default ProductStockList;