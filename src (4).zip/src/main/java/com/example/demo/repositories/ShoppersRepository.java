package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Shoppers;

public interface ShoppersRepository extends JpaRepository<Shoppers, Integer> 
{

}
